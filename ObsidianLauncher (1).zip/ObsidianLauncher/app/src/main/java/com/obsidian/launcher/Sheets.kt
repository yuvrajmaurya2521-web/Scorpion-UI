package com.obsidian.launcher

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SheetBg = Color(0xFF14141B)
private val Swatches = listOf(
    0xFFFFFFFF, 0xFFFF4FA3, 0xFFFF3B30, 0xFFFF8A3D, 0xFFFFD23F, 0xFFA3E635,
    0xFF25D366, 0xFF34D1FF, 0xFF4DA3FF, 0xFF8F7BFF, 0xFFB36BFF, 0xFFFF7AB8
).map { Color(it) }

@Composable
private fun Label(t: String) =
    Text(t, color = Color(0xFF8D8D9C), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))

/** Icon dabake rakhne par: color, style, speed, hide, info, uninstall */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun IconSheet(
    app: AppInfo,
    store: Store,
    inVault: Boolean,
    inHome: Boolean,
    inDock: Boolean,
    onToggleHome: () -> Unit,
    onToggleDock: () -> Unit,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val pkg = app.pkg
    val color = Color(store.color(pkg, app.defaultColor))
    var name by remember { mutableStateOf(store.label(pkg, app.label)) }
    var hue by remember { mutableStateOf(0f) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SheetBg) {
        Column(
            Modifier
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                GlowIcon(app, color, store.speed(pkg), store.style(pkg), 60.dp)
                Text(app.label, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it; store.setLabel(pkg, it) },
                label = { Text("Naam") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Label("GLOW COLOR")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Swatches.forEach { c ->
                    Box(
                        Modifier
                            .size(34.dp)
                            .background(c, CircleShape)
                            .then(if (c == color) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                            .clickable { store.setColor(pkg, c.toArgb()) }
                    )
                }
            }
            Label("POORA HUE SLIDER")
            Slider(
                value = hue,
                onValueChange = {
                    hue = it
                    store.setColor(pkg, Color.hsv(it, 0.85f, 1f).toArgb())
                },
                valueRange = 0f..360f
            )

            Label("STYLE")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Ghoomta glow", "Pulse", "Liquid").forEachIndexed { i, t ->
                    FilterChip(selected = store.style(pkg) == i, onClick = { store.setStyle(pkg, i) }, label = { Text(t) })
                }
            }

            Label("SPEED")
            Slider(value = store.speed(pkg), onValueChange = { store.setSpeed(pkg, it) }, valueRange = 0.3f..3f)

            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = {
                    store.setHidden(pkg, !inVault)
                    onDismiss()
                }) { Text(if (inVault) "Unhide karo" else "Hide karo") }
                if (!inVault) {
                    FilledTonalButton(onClick = onToggleHome) { Text(if (inHome) "Home se hatao" else "Home par rakho") }
                    FilledTonalButton(onClick = onToggleDock) { Text(if (inDock) "Dock se hatao" else "Dock mein rakho") }
                }
                OutlinedButton(onClick = { Sys.appInfo(ctx, pkg) }) { Text("App info") }
                OutlinedButton(onClick = { Sys.uninstall(ctx, pkg) }) { Text("Uninstall") }
                OutlinedButton(onClick = { store.resetColor(pkg); store.setStyle(pkg, 0); store.setSpeed(pkg, 1f) }) { Text("Reset") }
            }
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Ho gaya") }
        }
    }
}

/** Wallpaper dabake rakhne par menu */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WallMenu(
    hasZone: Boolean,
    onChangeWall: () -> Unit,
    onHide: () -> Unit,
    onSetZone: () -> Unit,
    onClearZone: () -> Unit,
    onSettings: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SheetBg) {
        Column(Modifier.padding(bottom = 32.dp)) {
            MenuRow("Wallpaper badlo", onChangeWall)
            MenuRow("Apps hide karo", onHide)
            MenuRow("Secret zone set karo", onSetZone)
            if (hasZone) MenuRow("Secret zone hatao", onClearZone)
            MenuRow("Settings aur permissions", onSettings)
        }
    }
}

@Composable
private fun MenuRow(t: String, onClick: () -> Unit) {
    Text(
        t, color = Color.White, fontSize = 16.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp)
    )
}

/** Kaunse apps hide karne hain (har app ke saamne switch) */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HidePicker(apps: List<AppInfo>, store: Store, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SheetBg) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text("Kaunse apps hide karne hain", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
            val hidden = store.hidden
            LazyColumn(Modifier.heightIn(max = 520.dp)) {
                items(apps, key = { it.pkg }) { a ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { store.setHidden(a.pkg, a.pkg !in hidden) }
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        GlowIcon(a, Color(store.color(a.pkg, a.defaultColor)), 1f, 1, 40.dp)
                        Text(store.label(a.pkg, a.label), color = Color.White, modifier = Modifier.weight(1f))
                        Switch(checked = a.pkg in hidden, onCheckedChange = { store.setHidden(a.pkg, it) })
                    }
                }
            }
        }
    }
}

@Composable
private fun PermRow(title: String, desc: String, ok: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.size(10.dp).background(if (ok) Color(0xFF58E08A) else Color(0xFFFF6B6B), CircleShape))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp)
            Text(desc, color = Color(0xFF8D8D9C), fontSize = 12.sp)
        }
        Text(if (ok) "ON" else "Kholo", color = Violet, fontSize = 13.sp)
    }
}

@Composable
private fun SwitchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Gestures, lock screen aur permissions ek jagah */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsSheet(
    store: Store,
    permRev: Int,
    onPickLockBg: () -> Unit,
    onPickCutout: () -> Unit,
    onPreviewLock: () -> Unit,
    onAskNotif: () -> Unit,
    onLockToggle: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    val ctx: Context = LocalContext.current
    @Suppress("UNUSED_VARIABLE") val trigger = permRev
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = SheetBg) {
        Column(
            Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

            Label("RECENTS APPS KAISE KHULE")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("bottom" to "Neeche se upar swipe", "edge" to "Side edge swipe", "double" to "Double tap").forEach { (k, t) ->
                    FilterChip(selected = store.recentsGesture == k, onClick = { store.setStr("g_recents", k) }, label = { Text(t) })
                }
            }
            Label("CONTROL CENTER KAISE KHULE")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("topright" to "Upar-right kona", "topfull" to "Poora upar ka edge").forEach { (k, t) ->
                    FilterChip(selected = store.ccGesture == k, onClick = { store.setStr("g_cc", k) }, label = { Text(t) })
                }
            }

            Label("IOS LOCK SCREEN")
            SwitchRow("Lock screen chalu karo", store.lockOn, onLockToggle)
            Label("CLOCK FONT")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LockFonts.names.forEachIndexed { i, n ->
                    FilterChip(selected = store.lockFont == i, onClick = { store.setInt("lock_font", i) }, label = { Text(n) })
                }
            }
            SwitchRow("Clock upar-neeche (09 / 41)", store.lockStack) { store.setBool("lock_stack", it) }
            SwitchRow("Depth effect (cutout PNG clock ke aage)", store.lockDepth) { store.setBool("lock_depth", it) }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FilledTonalButton(onClick = onPickLockBg) { Text("Lock wallpaper chuno") }
                FilledTonalButton(onClick = onPickCutout) { Text("Depth cutout PNG chuno") }
                OutlinedButton(onClick = onPreviewLock) { Text("Preview dekho") }
            }

            Label("PERMISSIONS (Vivo T2x par ek baar dena hai)")
            PermRow("Default launcher", "Home button dabane par Obsidian khule", false) { Sys.openHomeSettings(ctx) }
            PermRow("Usage Access", "Recents apps ke liye", Sys.hasUsage(ctx)) { Sys.openUsage(ctx) }
            PermRow("Display over other apps", "Lock screen ko screen on par dikhane ke liye", Sys.hasOverlay(ctx)) { Sys.openOverlay(ctx) }
            PermRow("Accessibility: Obsidian Control Center", "Upar-right swipe se Control Center", ControlCenterService.instance != null) { Sys.openAccessibility(ctx) }
            PermRow("Modify system settings", "Brightness slider aur auto-rotate", Sys.hasWriteSettings(ctx)) { Sys.openWriteSettings(ctx) }
            PermRow("Notifications", "Lock screen service ke liye", false, onAskNotif)
            PermRow("Full screen intents", "Lock screen kuch phones par isse khulti hai", false) { Sys.openFullScreenIntent(ctx) }
        }
    }
}
