package com.obsidian.launcher

import android.app.AlarmManager
import android.app.KeyguardManager
import android.content.Context
import android.graphics.BitmapFactory
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** iOS style lock screen. Asli lock screen ke upar dikhti hai, upar swipe karne par asli PIN/fingerprint aata hai. */
class LockActivity : ComponentActivity() {
    private var preview = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preview = intent?.getBooleanExtra("preview", false) == true
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        enableEdgeToEdge()
        val store = Store(this)
        setContent {
            ObsidianTheme {
                LockScreen(store) { unlock() }
            }
        }
    }

    private fun unlock() {
        if (preview) {
            finish()
            return
        }
        val km = getSystemService(KeyguardManager::class.java)
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissError() { finish() }
        })
    }
}

@Composable
fun LockScreen(store: Store, onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(1000)
        }
    }
    val rev = store.lockImgRev
    val bg = remember(rev) { decode(File(ctx.filesDir, "lock_bg.img")) }
    val cut = remember(rev) { decode(File(ctx.filesDir, "lock_cut.png")) }

    val font = LockFonts.family(store.lockFont)
    val hh = SimpleDateFormat("HH", Locale.getDefault()).format(now)
    val mm = SimpleDateFormat("mm", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    val battery = remember(now) { ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
    val alarm = remember(now) {
        val a = ctx.getSystemService(AlarmManager::class.java).nextAlarmClock
        if (a == null) "Alarm nahi" else SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(a.triggerTime))
    }
    var torch by remember { mutableStateOf(Torch.on) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1233), Color(0xFF47285F), Color(0xFFD4607A), Color(0xFFFFB27A))))
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onVerticalDrag = { _, d -> acc += d },
                    onDragEnd = { if (acc < -160f) onUnlock() }
                )
            }
    ) {
        if (bg != null) {
            Image(bg.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Color(0x33000000)))
        }

        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(top = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(date, color = Color.White.copy(alpha = 0.9f), fontSize = 17.sp)
            val clockStyle = TextStyle(fontFamily = font, color = Color.White.copy(alpha = 0.95f), textAlign = TextAlign.Center)
            if (store.lockStack) {
                Text(hh, style = clockStyle, fontSize = 128.sp, lineHeight = 116.sp)
                Text(mm, style = clockStyle, fontSize = 128.sp, lineHeight = 116.sp)
            } else {
                Text("$hh:$mm", style = clockStyle, fontSize = 88.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }

        // Depth effect: subject ka transparent PNG clock ke upar aata hai
        if (store.lockDepth && cut != null) {
            Image(cut.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().systemBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Widget("Battery", "$battery%", Modifier.weight(1f))
                Widget("Alarm", alarm, Modifier.weight(1f))
                Widget("Aaj", SimpleDateFormat("d MMM", Locale.getDefault()).format(now), Modifier.weight(1f))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(50.dp)
                        .background(if (torch) Color.White else Color(0x44000000), CircleShape)
                        .clickable { torch = Torch.toggle(ctx) },
                    contentAlignment = Alignment.Center
                ) {
                    Text("🔦", fontSize = 20.sp)
                }
                Text(
                    "Upar swipe karke unlock karo",
                    color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
                Box(Modifier.size(50.dp))
            }
        }
    }
}

@Composable
private fun Widget(title: String, value: String, modifier: Modifier) {
    Column(
        modifier
            .background(Color(0x33FFFFFF), RoundedCornerShape(18.dp))
            .padding(12.dp)
    ) {
        Text(title, color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
        Text(value, color = Color.White, fontSize = 17.sp, maxLines = 1)
    }
}

private fun decode(f: File): android.graphics.Bitmap? {
    if (!f.exists()) return null
    return try {
        BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = 2 })
    } catch (_: Throwable) {
        null
    }
}
