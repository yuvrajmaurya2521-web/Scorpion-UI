package com.obsidian.launcher

import android.Manifest
import android.app.WallpaperManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.contracts.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

class MainActivity : FragmentActivity() {
    val homeSignal = mutableIntStateOf(0)
    private lateinit var store: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        store = Store(this)
        setContent { ObsidianTheme { Root(this, store) } }
        if (store.lockOn) LockService.start(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button dabane par sab band hokar home par aa jao
        homeSignal.intValue++
    }
}

@Composable
fun Root(act: MainActivity, store: Store) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density
    val clock = remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) androidx.compose.runtime.withFrameNanos { clock.longValue = it }
    }

    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var loadKey by remember { mutableIntStateOf(0) }
    var permRev by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        loadKey++
        permRev++
    }
    LaunchedEffect(loadKey) {
        val n = withContext(Dispatchers.Default) { AppRepo.load(ctx) }
        if (n.map { it.pkg } != apps.map { it.pkg }) apps = n
    }

    var screen by remember { mutableStateOf("home") } // home, drawer, recents, vault
    var iconSheet by remember { mutableStateOf<String?>(null) }
    var wallMenu by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var hidePicker by remember { mutableStateOf(false) }
    var zoneMode by remember { mutableStateOf(false) }

    LaunchedEffect(act.homeSignal.intValue) {
        screen = "home"
        iconSheet = null
        wallMenu = false
        settings = false
        hidePicker = false
        zoneMode = false
    }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) {
        if (screen == "vault") screen = "home"
    }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    // ---- pickers ----
    val wallPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use {
                        WallpaperManager.getInstance(ctx).setStream(it, null, true, WallpaperManager.FLAG_SYSTEM)
                    }
                    true
                } catch (_: Throwable) {
                    false
                }
            }
            toast(if (ok) "Wallpaper badal gaya (Recents ke peeche bhi dikhega)" else "Wallpaper nahi badal paya")
        }
    }
    fun copyPicker(name: String): (Uri?) -> Unit = { uri ->
        if (uri != null) scope.launch {
            withContext(Dispatchers.IO) {
                try {
                    ctx.contentResolver.openInputStream(uri)?.use { i ->
                        File(ctx.filesDir, name).outputStream().use { o -> i.copyTo(o) }
                    }
                } catch (_: Throwable) {
                }
            }
            store.setInt("lock_img_rev", store.lockImgRev + 1)
            toast("Save ho gaya")
        }
    }
    val bgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent(), copyPicker("lock_bg.img"))
    val cutPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent(), copyPicker("lock_cut.png"))
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    // ---- derived lists (hidden apps har jagah se bahar) ----
    val hidden = store.hidden
    val byPkg = apps.associateBy { it.pkg }
    val visible = apps.filter { it.pkg !in hidden }
    val defDock = remember(apps) { AppRepo.defaultDock(ctx, apps) }
    val dockPk = (store.dock() ?: defDock).filter { it in byPkg && it !in hidden }.take(4)
    val homePk = (store.homeApps() ?: visible.filter { it.pkg !in dockPk }.take(16).map { it.pkg })
        .filter { it in byPkg && it !in hidden && it !in dockPk }

    fun toggleHome(pkg: String) {
        val cur = homePk.toMutableList()
        if (pkg in cur) cur.remove(pkg) else {
            cur.add(pkg)
            if (pkg in dockPk) store.setDock(dockPk - pkg)
        }
        store.setHome(cur)
    }

    fun toggleDock(pkg: String) {
        if (pkg in dockPk) {
            store.setDock(dockPk - pkg)
            store.setHome(homePk + pkg)
        } else {
            if (dockPk.size >= 4) {
                toast("Dock full hai (4 apps)")
                return
            }
            store.setDock(dockPk + pkg)
            store.setHome(homePk - pkg)
        }
    }

    fun openApp(a: AppInfo) {
        screen = if (screen == "vault") "vault" else "home"
        Sys.launch(ctx, a.pkg)
    }

    val zone = store.zone()

    CompositionLocalProvider(LocalClock provides clock) {
        Box(
            Modifier
                .fillMaxSize()
                .swipeWatcher { start, d, size ->
                    if (screen != "home" || zoneMode || wallMenu || settings || hidePicker || iconSheet != null) return@swipeWatcher
                    val w = size.width
                    val h = size.height
                    val dx = d.x
                    val dy = d.y
                    when {
                        start.y < h * 0.07f && dy > 90 * density && abs(dy) > abs(dx) &&
                            (store.ccGesture == "topfull" || start.x > w * 0.55f) -> {
                            val s = ControlCenterService.instance
                            if (s != null) s.showPanel() else {
                                toast("Control Center ke liye Accessibility service chalu karo")
                                Sys.openAccessibility(ctx)
                            }
                        }
                        store.recentsGesture == "bottom" && start.y > h * 0.93f && dy < -80 * density && abs(dy) > abs(dx) ->
                            screen = "recents"
                        store.recentsGesture == "edge" && (start.x < 28 * density || start.x > w - 28 * density) &&
                            abs(dx) > 90 * density && abs(dx) > abs(dy) * 1.5f -> screen = "recents"
                        dy < -120 * density && abs(dy) > abs(dx) * 1.5f && start.y > h * 0.1f && start.y < h * 0.93f ->
                            screen = "drawer"
                    }
                    Unit
                }
        ) {
            // ---------------- HOME ----------------
            val gestRecents = store.recentsGesture
            Box(
                Modifier
                    .fillMaxSize()
                    .pointerInput(zone, zoneMode, gestRecents) {
                        val sz = size
                        val dbl: ((Offset) -> Unit)? =
                            if (gestRecents == "double") ({ _: Offset -> screen = "recents" }) else null
                        detectTapGestures(
                            onDoubleTap = dbl,
                            onLongPress = { if (!zoneMode) wallMenu = true },
                            onTap = { pos ->
                                if (zoneMode) {
                                    store.setZone(pos.x / sz.width, pos.y / sz.height)
                                    zoneMode = false
                                    toast("Secret zone set ho gaya. Ab wahan tap karo")
                                } else if (zone != null) {
                                    val c = Offset(zone.x * sz.width, zone.y * sz.height)
                                    if ((pos - c).getDistance() < 40 * density) {
                                        Vault.authenticate(act) { screen = "vault" }
                                    }
                                }
                            }
                        )
                    }
            ) {
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Color.Transparent, Color(0x88000000)))
                    )
                )
                Column(Modifier.fillMaxSize().systemBarsPadding()) {
                    ClockWidget()
                    HomePager(
                        homePk.mapNotNull { byPkg[it] }, store, Modifier.weight(1f),
                        onOpen = { openApp(it) }, onLong = { iconSheet = it.pkg }
                    )
                    Dock(dockPk.mapNotNull { byPkg[it] }, store, onOpen = { openApp(it) }, onLong = { iconSheet = it.pkg })
                }
                if (zoneMode) {
                    Box(Modifier.fillMaxSize().background(Color(0x99000000)))
                    if (zone != null) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawCircle(
                                Violet, radius = 40 * density,
                                center = Offset(zone.x * size.width, zone.y * size.height),
                                style = Stroke(2 * density, pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
                            )
                        }
                    }
                    Column(
                        Modifier.align(Alignment.Center).padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "Wallpaper par kahin bhi tap karo.\nWahi secret zone banega.",
                            color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center
                        )
                        Button(onClick = { zoneMode = false }, modifier = Modifier.padding(top = 16.dp)) { Text("Cancel") }
                    }
                }
            }

            // ---------------- OVERLAY SCREENS ----------------
            AnimatedVisibility(
                screen == "drawer",
                enter = slideInVertically { it / 2 } + fadeIn(),
                exit = slideOutVertically { it / 2 } + fadeOut()
            ) {
                Drawer(visible, store, onOpen = { openApp(it) }, onLong = { iconSheet = it.pkg }, onClose = { screen = "home" })
            }
            AnimatedVisibility(screen == "recents", enter = fadeIn(), exit = fadeOut()) {
                RecentsScreen(visible, store, onOpen = { openApp(it) }, onClose = { screen = "home" })
            }
            AnimatedVisibility(screen == "vault", enter = fadeIn(), exit = fadeOut()) {
                VaultScreen(
                    apps.filter { it.pkg in hidden }, store,
                    onOpen = { Sys.launch(ctx, it.pkg) },
                    onLong = { iconSheet = it.pkg },
                    onClose = { screen = "home" }
                )
            }
        }

        // ---------------- SHEETS ----------------
        iconSheet?.let { pkg ->
            byPkg[pkg]?.let { app ->
                IconSheet(
                    app = app, store = store,
                    inVault = pkg in hidden,
                    inHome = pkg in homePk,
                    inDock = pkg in dockPk,
                    onToggleHome = { toggleHome(pkg) },
                    onToggleDock = { toggleDock(pkg) },
                    onDismiss = { iconSheet = null }
                )
            }
        }
        if (wallMenu) {
            WallMenu(
                hasZone = zone != null,
                onChangeWall = { wallMenu = false; wallPicker.launch("image/*") },
                onHide = { wallMenu = false; hidePicker = true },
                onSetZone = { wallMenu = false; zoneMode = true },
                onClearZone = { store.clearZone(); wallMenu = false; toast("Secret zone hata diya") },
                onSettings = { wallMenu = false; settings = true },
                onDismiss = { wallMenu = false }
            )
        }
        if (hidePicker) HidePicker(apps, store) { hidePicker = false }
        if (settings) {
            SettingsSheet(
                store = store,
                permRev = permRev,
                onPickLockBg = { bgPicker.launch("image/*") },
                onPickCutout = { cutPicker.launch("image/png") },
                onPreviewLock = {
                    settings = false
                    ctx.startActivity(Intent(ctx, LockActivity::class.java).putExtra("preview", true))
                },
                onAskNotif = { notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) },
                onLockToggle = { on ->
                    store.setBool("lock_on", on)
                    if (on) {
                        if (!Sys.hasOverlay(ctx)) {
                            toast("Pehle 'Display over other apps' permission do")
                            Sys.openOverlay(ctx)
                        }
                        LockService.start(ctx)
                    } else {
                        LockService.stop(ctx)
                    }
                },
                onDismiss = { settings = false }
            )
        }
    }
}
