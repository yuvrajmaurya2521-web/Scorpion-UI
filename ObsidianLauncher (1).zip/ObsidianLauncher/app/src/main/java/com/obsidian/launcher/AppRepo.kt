package com.obsidian.launcher

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.sqrt

data class AppInfo(
    val pkg: String,
    val label: String,
    val icon: ImageBitmap,
    val edge: ImageBitmap,
    val defaultColor: Int
)

object AppRepo {
    private const val SIZE = 128
    private val cache = HashMap<String, AppInfo>()

    fun load(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
        val out = ArrayList<AppInfo>()
        val seen = HashSet<String>()
        for (ri in list) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val cached = cache[pkg]
            if (cached != null) {
                out.add(cached)
                continue
            }
            try {
                val bmp = ri.loadIcon(pm).toBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
                val info = AppInfo(
                    pkg = pkg,
                    label = ri.loadLabel(pm).toString(),
                    icon = bmp.asImageBitmap(),
                    edge = edges(bmp).asImageBitmap(),
                    defaultColor = dominantColor(bmp)
                )
                cache[pkg] = info
                out.add(info)
            } catch (_: Throwable) {
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    /** Dock ke liye default: Phone, Messages, Browser, Camera */
    fun defaultDock(ctx: Context, apps: List<AppInfo>): List<String> {
        val pm = ctx.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val have = apps.map { it.pkg }.toSet()
        val res = ArrayList<String>()
        for (intent in intents) {
            val p = try {
                pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            } catch (_: Throwable) {
                null
            }
            if (p != null && p in have && p !in res) res.add(p)
        }
        for (a in apps) {
            if (res.size >= 4) break
            if (a.pkg !in res) res.add(a.pkg)
        }
        return res.take(4)
    }

    /** Sobel edge detect: icon ke andar ki lines (jaise X ki do lines) nikalta hai. */
    private fun edges(src: Bitmap): Bitmap {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val lum = FloatArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            val a = (c ushr 24) / 255f
            val l = (0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)) / 255f
            lum[i] = l * a
        }
        val out = IntArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val i = y * w + x
                val gx = -lum[i - w - 1] - 2 * lum[i - 1] - lum[i + w - 1] + lum[i - w + 1] + 2 * lum[i + 1] + lum[i + w + 1]
                val gy = -lum[i - w - 1] - 2 * lum[i - w] - lum[i - w + 1] + lum[i + w - 1] + 2 * lum[i + w] + lum[i + w + 1]
                val m = sqrt(gx * gx + gy * gy)
                val a = ((m - 0.3f) * 3f).coerceIn(0f, 1f)
                out[i] = ((a * 255).toInt() shl 24) or 0xFFFFFF
            }
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Icon ka sabse zyada dikhne wala rang. Rang na mile to white. */
    private fun dominantColor(bmp: Bitmap): Int {
        val buckets = IntArray(12)
        var total = 0
        val hsv = FloatArray(3)
        val step = 4
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                val c = bmp.getPixel(x, y)
                if ((c ushr 24) > 200) {
                    total++
                    android.graphics.Color.colorToHSV(c, hsv)
                    if (hsv[1] > 0.4f && hsv[2] > 0.45f) buckets[(hsv[0] / 30f).toInt().coerceIn(0, 11)]++
                }
                x += step
            }
            y += step
        }
        var best = 0
        for (i in 1 until 12) if (buckets[i] > buckets[best]) best = i
        if (total == 0 || buckets[best] < total * 0.12f) return 0xFFFFFFFF.toInt()
        return android.graphics.Color.HSVToColor(floatArrayOf(best * 30f + 15f, 0.8f, 1f))
    }

    /** Recent packages (naye pehle). Usage Access permission chahiye. */
    fun recents(ctx: Context): List<String> {
        val usm = ctx.getSystemService(UsageStatsManager::class.java) ?: return emptyList()
        val end = System.currentTimeMillis()
        val ev = usm.queryEvents(end - 3L * 24 * 3600 * 1000, end)
        val e = UsageEvents.Event()
        val last = HashMap<String, Long>()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) last[e.packageName] = e.timeStamp
        }
        return last.entries.sortedByDescending { it.value }.map { it.key }
    }
}
