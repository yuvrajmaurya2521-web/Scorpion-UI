package com.obsidian.launcher

import android.accessibilityservice.AccessibilityService
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/**
 * Control Center. Accessibility overlay hai, isliye kisi bhi app ke upar chalta hai.
 * Upar-right kone se neeche swipe karo.
 */
class ControlCenterService : AccessibilityService() {

    companion object {
        var instance: ControlCenterService? = null
    }

    private lateinit var wm: WindowManager
    private var strip: View? = null
    private var panel: FrameLayout? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addStrip()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        removePanel()
        strip?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        strip = null
        instance = null
        return super.onUnbind(intent)
    }

    private fun addStrip() {
        val v = View(this)
        val w = (resources.displayMetrics.widthPixels * 0.42f).toInt()
        val lp = WindowManager.LayoutParams(
            w, dp(26),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        v.setOnTouchListener(object : View.OnTouchListener {
            var y0 = 0f
            var done = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { y0 = e.rawY; done = false }
                    MotionEvent.ACTION_MOVE -> if (!done && e.rawY - y0 > dp(40)) {
                        done = true
                        showPanel()
                    }
                }
                return true
            }
        })
        wm.addView(v, lp)
        strip = v
    }

    private fun go(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Throwable) {
            Toast.makeText(this, "Ye screen is phone par nahi khuli", Toast.LENGTH_SHORT).show()
        }
        removePanel()
    }

    private fun paint(v: LinearLayout, on: Boolean) {
        (v.background as GradientDrawable).setColor(if (on) 0xFF8F7BFF.toInt() else 0x22FFFFFF)
        (v.getChildAt(1) as TextView).setTextColor(if (on) 0xFF0A0A12.toInt() else Color.WHITE)
    }

    private fun tile(icon: String, label: String, on: Boolean, click: (LinearLayout) -> Unit): LinearLayout {
        val ctx = this
        val t = LinearLayout(ctx)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(4), dp(12), dp(4), dp(12))
        t.background = GradientDrawable().apply { cornerRadius = dp(20).toFloat() }
        t.addView(TextView(ctx).apply { text = icon; textSize = 22f; gravity = Gravity.CENTER })
        t.addView(TextView(ctx).apply { text = label; textSize = 11f; gravity = Gravity.CENTER; maxLines = 1 })
        paint(t, on)
        t.setOnClickListener { click(t) }
        return t
    }

    private fun row(vararg tiles: LinearLayout): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (t in tiles) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            r.addView(t, lp)
        }
        return r
    }

    private fun slider(title: String, max: Int, cur: Int, onChange: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(8), dp(10), dp(8), 0)
        box.addView(TextView(this).apply { text = title; textSize = 12f; setTextColor(0xFF8D8D9C.toInt()) })
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = cur
        sb.progressTintList = ColorStateList.valueOf(0xFF8F7BFF.toInt())
        sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) onChange(p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb)
        return box
    }

    fun showPanel() {
        if (panel != null) return
        val root = FrameLayout(this)
        root.setBackgroundColor(0x99000000.toInt())
        root.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) removePanel()
            true
        }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(14), dp(14), dp(14), dp(14))
        card.isClickable = true
        card.background = GradientDrawable().apply {
            cornerRadius = dp(28).toFloat()
            setColor(0xF2181820.toInt())
            setStroke(dp(1), 0x22FFFFFF)
        }

        val wifi = getSystemService(Context.WIFI_SERVICE) as WifiManager
        val wifiOn = try { wifi.isWifiEnabled } catch (_: Throwable) { false }
        val btOn = try { (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true } catch (_: Throwable) { false }
        val rotOn = try { Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0) == 1 } catch (_: Throwable) { false }

        card.addView(row(
            tile("📶", "Wi-Fi", wifiOn) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) },
            tile("🔵", "Bluetooth", btOn) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
            tile("📡", "Mobile data", false) {
                try {
                    go(Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS))
                } catch (_: Throwable) {
                    go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                }
            },
            tile("🔦", "Torch", Torch.on) { t -> paint(t, Torch.toggle(this)) }
        ))
        card.addView(row(
            tile("🔄", "Rotate", rotOn) { t ->
                if (!Settings.System.canWrite(this)) {
                    go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName")))
                } else {
                    val now = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 0)
                    Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (now == 1) 0 else 1)
                    paint(t, now != 1)
                }
            },
            tile("🔒", "Lock", false) {
                removePanel()
                performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            },
            tile("📸", "Screenshot", false) {
                removePanel()
                root.postDelayed({ performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) }, 350)
            },
            tile("⚙️", "Settings", false) { go(Intent(Settings.ACTION_SETTINGS)) }
        ))

        val bri = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) } catch (_: Throwable) { 128 }
        card.addView(slider("Brightness", 255, bri) { p ->
            if (!Settings.System.canWrite(this)) {
                go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:$packageName")))
            } else {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceAtLeast(5))
            }
        })
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        card.addView(slider("Volume", am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), am.getStreamVolume(AudioManager.STREAM_MUSIC)) { p ->
            am.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
        })
        card.addView(TextView(this).apply {
            text = "Band karo"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(0xFF8F7BFF.toInt())
            setPadding(0, dp(14), 0, dp(4))
            setOnClickListener { removePanel() }
        })

        val clp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.setMargins(dp(12), dp(44), dp(12), 0)
        root.addView(card, clp)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = 40
        }
        wm.addView(root, lp)
        panel = root
        root.alpha = 0f
        card.translationY = -dp(60).toFloat()
        root.animate().alpha(1f).setDuration(180).start()
        card.animate().translationY(0f).setDuration(240).start()
    }

    private fun removePanel() {
        val p = panel ?: return
        panel = null
        p.animate().alpha(0f).setDuration(140).withEndAction {
            try { wm.removeView(p) } catch (_: Throwable) {}
        }.start()
    }
}
