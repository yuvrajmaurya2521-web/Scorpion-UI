package com.obsidian.launcher

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Process
import android.provider.Settings
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.ui.text.font.FontFamily
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object Sys {
    fun launch(ctx: Context, pkg: String) {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (_: Throwable) {
        }
    }

    fun appInfo(ctx: Context, pkg: String) = startSafe(
        ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
    )

    fun uninstall(ctx: Context, pkg: String) = startSafe(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))

    fun startSafe(ctx: Context, i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (_: Throwable) {
            Toast.makeText(ctx, "Ye screen is phone par nahi khuli", Toast.LENGTH_SHORT).show()
        }
    }

    fun hasUsage(ctx: Context): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java) ?: return false
        val m = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return m == AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlay(ctx: Context) = Settings.canDrawOverlays(ctx)
    fun hasWriteSettings(ctx: Context) = Settings.System.canWrite(ctx)

    fun openUsage(ctx: Context) = startSafe(ctx, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
    fun openOverlay(ctx: Context) =
        startSafe(ctx, Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))

    fun openWriteSettings(ctx: Context) =
        startSafe(ctx, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))

    fun openAccessibility(ctx: Context) = startSafe(ctx, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    fun openHomeSettings(ctx: Context) = startSafe(ctx, Intent(Settings.ACTION_HOME_SETTINGS))
    fun openFullScreenIntent(ctx: Context) = startSafe(
        ctx, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${ctx.packageName}"))
    )
}

/** Biometric (fingerprint / face) ya device PIN-pattern-password */
object Vault {
    fun authenticate(act: FragmentActivity, onOk: () -> Unit) {
        val auth = BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val can = BiometricManager.from(act).canAuthenticate(auth)
        if (can != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(act, "Pehle phone mein screen lock ya fingerprint set karo", Toast.LENGTH_LONG).show()
            return
        }
        val prompt = BiometricPrompt(
            act, ContextCompat.getMainExecutor(act),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onOk()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Vault kholo")
            .setSubtitle("Fingerprint, Face ya PIN se verify karo")
            .setAllowedAuthenticators(auth)
            .build()
        prompt.authenticate(info)
    }
}

object Torch {
    var on = false
        private set

    private fun camId(ctx: Context): String? {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }

    fun toggle(ctx: Context): Boolean {
        try {
            val id = camId(ctx) ?: return false
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            on = !on
            cm.setTorchMode(id, on)
        } catch (_: Throwable) {
            on = false
        }
        return on
    }
}

/** Lock screen ke 8 clock fonts (phone ke apne system fonts, koi download nahi) */
object LockFonts {
    val names = listOf("Thin", "Light", "Regular", "Medium", "Black", "Condensed", "Serif", "Mono")

    fun family(i: Int): FontFamily {
        val tf = when (i) {
            0 -> android.graphics.Typeface.create("sans-serif-thin", android.graphics.Typeface.NORMAL)
            1 -> android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            2 -> android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            3 -> android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            4 -> android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.NORMAL)
            5 -> android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD)
            6 -> android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
            else -> android.graphics.Typeface.create("monospace", android.graphics.Typeface.NORMAL)
        }
        return FontFamily(tf)
    }
}
