package com.obsidian.launcher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableLongState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

val Violet = Color(0xFF8F7BFF)

@Composable
fun ObsidianTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            onPrimary = Color(0xFF0A0A12),
            surface = Color(0xFF14141B),
            surfaceVariant = Color(0xFF1E1E28),
            background = Color(0xFF050507),
            onSurface = Color(0xFFF1F1F5)
        ),
        content = content
    )
}

/** Ek hi clock sabhi icons ke liye. Isse 30+ icons bhi smooth chalte hain. */
val LocalClock = compositionLocalOf<MutableLongState> { mutableLongStateOf(0L) }

/**
 * Glowing icon.
 * style 0 = outline par ghoomta neon glow, 1 = pulse, 2 = liquid blobs + glow
 * Icon ki asli lines (edge) ke upar glow chalta hai, jaise X ki white lines.
 */
@Composable
fun GlowIcon(app: AppInfo, color: Color, speed: Float, style: Int, size: Dp, modifier: Modifier = Modifier) {
    val clock = LocalClock.current
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val sec = clock.longValue / 1_000_000_000f
        val period = 6f / speed.coerceAtLeast(0.2f)
        val ang = (sec / period * 360f) % 360f
        val twoPi = 6.2831855f
        val pulse = 0.3f + 0.7f * (0.5f + 0.5f * sin(sec * twoPi / (period * 0.6f)))
        val drift = 0.5f + 0.5f * sin(sec * twoPi / (period * 1.4f))
        val drift2 = 0.5f + 0.5f * sin(sec * twoPi / (period * 1.1f) + 2f)
        val corner = CornerRadius(w * 0.27f, w * 0.27f)
        val clip = Path().apply { addRoundRect(RoundRect(0f, 0f, w, h, corner)) }
        val inset = (w * 0.1f).toInt()
        val off = IntOffset(inset, inset)
        val dst = IntSize((w - 2 * inset).toInt(), (h - 2 * inset).toInt())
        val center = Offset(w / 2f, h / 2f)

        clipPath(clip) {
            drawRect(Color(0xFF0C0C12))
            drawImage(app.icon, dstOffset = off, dstSize = dst, alpha = 0.5f)

            if (style == 2) {
                val c1 = Offset(w * (0.2f + 0.6f * drift), h * (0.8f - 0.6f * drift2))
                val c2 = Offset(w * (0.8f - 0.6f * drift2), h * (0.2f + 0.6f * drift))
                drawCircle(
                    Brush.radialGradient(listOf(color.copy(alpha = 0.55f), Color.Transparent), center = c1, radius = w * 0.7f),
                    radius = w * 0.7f, center = c1
                )
                drawCircle(
                    Brush.radialGradient(listOf(color.copy(alpha = 0.4f), Color.Transparent), center = c2, radius = w * 0.6f),
                    radius = w * 0.6f, center = c2
                )
            }

            // halki white outline (hamesha dikhti hai)
            drawImage(
                app.edge, dstOffset = off, dstSize = dst, alpha = 0.38f,
                colorFilter = ColorFilter.tint(Color.White, BlendMode.SrcIn)
            )

            if (style == 1) {
                drawImage(
                    app.edge, dstOffset = off, dstSize = dst, alpha = pulse,
                    colorFilter = ColorFilter.tint(color, BlendMode.SrcIn)
                )
            } else {
                drawIntoCanvas { canvas ->
                    canvas.saveLayer(Rect(0f, 0f, w, h), Paint())
                    drawImage(
                        app.edge, dstOffset = off, dstSize = dst,
                        colorFilter = ColorFilter.tint(color, BlendMode.SrcIn)
                    )
                    rotate(ang, center) {
                        drawRect(
                            brush = Brush.sweepGradient(
                                0.00f to Color.Transparent,
                                0.15f to Color.Transparent,
                                0.42f to Color.White,
                                0.47f to Color.Transparent,
                                0.65f to Color.Transparent,
                                0.92f to Color.White,
                                0.97f to Color.Transparent,
                                1.00f to Color.Transparent,
                                center = center
                            ),
                            topLeft = Offset(-w, -h),
                            size = Size(3 * w, 3 * h),
                            blendMode = BlendMode.DstIn
                        )
                    }
                    canvas.restore()
                }
            }
        }
        drawRoundRect(
            color.copy(alpha = if (style == 1) 0.2f + 0.3f * pulse else 0.4f),
            cornerRadius = corner, style = Stroke(width = w * 0.03f)
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppItem(
    app: AppInfo,
    store: Store,
    showLabel: Boolean = true,
    onClick: () -> Unit,
    onLong: () -> Unit
) {
    val haptic = LocalHapticFeedback.current
    val c = Color(store.color(app.pkg, app.defaultColor))
    Column(
        Modifier
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLong()
                }
            )
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        GlowIcon(app, c, store.speed(app.pkg), store.style(app.pkg), 56.dp)
        if (showLabel) {
            Text(
                store.label(app.pkg, app.label),
                color = Color.White.copy(alpha = 0.92f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 6f)),
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
