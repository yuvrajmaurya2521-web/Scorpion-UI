package com.obsidian.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

/** Samsung One UI jaisa stacked-card recents. Hidden apps yahan kabhi nahi aate. */
@Composable
fun RecentsScreen(apps: List<AppInfo>, store: Store, onOpen: (AppInfo) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)
    var granted by remember { mutableStateOf(Sys.hasUsage(ctx)) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = Sys.hasUsage(ctx) }
    val cards = remember { mutableStateListOf<String>() }
    val byPkg = apps.associateBy { it.pkg }
    val hidden = store.hidden

    LaunchedEffect(granted) {
        if (granted) {
            val r = withContext(Dispatchers.IO) { AppRepo.recents(ctx) }
            cards.clear()
            cards.addAll(r.filter { it in byPkg }.take(10))
        }
    }
    val shown = cards.filter { it in byPkg && it !in hidden }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xD9050507))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
            .systemBarsPadding()
    ) {
        if (!granted) {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("Recents ke liye Usage Access chahiye", color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center)
                Text("Settings mein Obsidian chuno aur Allow karo.", color = Color(0xFF8D8D9C), textAlign = TextAlign.Center)
                Button(onClick = { Sys.openUsage(ctx) }) { Text("Permission do") }
            }
        } else if (shown.isEmpty()) {
            Text("Abhi koi recent app nahi", color = Color.White.copy(alpha = 0.8f), modifier = Modifier.align(Alignment.Center))
        } else {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val cardW = maxWidth * 0.66f
                val cardWpx = with(LocalDensity.current) { cardW.toPx() }
                val state = rememberPagerState { shown.size }
                HorizontalPager(
                    state,
                    Modifier.align(Alignment.Center).fillMaxWidth().height(maxHeight * 0.6f),
                    contentPadding = PaddingValues(horizontal = (maxWidth - cardW) / 2),
                    key = { shown[it] },
                    beyondViewportPageCount = 2
                ) { page ->
                    val pkg = shown[page]
                    val app = byPkg[pkg]
                    if (app != null) {
                        val off = (state.currentPage - page) + state.currentPageOffsetFraction
                        var dragY by remember(pkg) { mutableFloatStateOf(0f) }
                        val c = Color(store.color(pkg, app.defaultColor))
                        Column(
                            Modifier
                                .zIndex(1f - abs(off))
                                .graphicsLayer {
                                    val s = 1f - abs(off).coerceAtMost(2f) * 0.1f
                                    scaleX = s
                                    scaleY = s
                                    translationX = off * cardWpx * 0.32f
                                    translationY = dragY
                                    rotationY = off * 14f
                                    cameraDistance = 14f * density
                                    alpha = (1f - abs(off) * 0.22f - (-dragY / 900f).coerceIn(0f, 1f)).coerceIn(0f, 1f)
                                }
                                .fillMaxSize()
                                .padding(horizontal = 4.dp)
                                .clip(RoundedCornerShape(28.dp))
                                .background(Brush.verticalGradient(listOf(Color(0xFF1C1C26), Color(0xFF0B0B10))))
                                .border(1.dp, c.copy(alpha = 0.35f), RoundedCornerShape(28.dp))
                                .pointerInput(pkg) {
                                    detectVerticalDragGestures(
                                        onDragEnd = { if (dragY < -260f) cards.remove(pkg) else dragY = 0f },
                                        onDragCancel = { dragY = 0f },
                                        onVerticalDrag = { _, d -> dragY = (dragY + d).coerceAtMost(0f) }
                                    )
                                }
                                .clickable { onOpen(app) }
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlowIcon(app, c, store.speed(pkg), store.style(pkg), 30.dp)
                                Text(store.label(pkg, app.label), color = Color.White, fontSize = 15.sp, maxLines = 1)
                            }
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                GlowIcon(app, c, store.speed(pkg), store.style(pkg), 104.dp)
                            }
                            Text("Kholne ke liye tap, hatane ke liye upar swipe", color = Color(0xFF8D8D9C), fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FilledTonalButton(onClick = { cards.clear() }) { Text("Sab hatao") }
            FilledTonalButton(onClick = onClose) { Text("Home") }
        }
    }
}
