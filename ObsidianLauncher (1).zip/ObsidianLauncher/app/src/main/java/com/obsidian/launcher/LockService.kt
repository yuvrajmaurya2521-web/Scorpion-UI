package com.obsidian.launcher

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/**
 * Screen on hote hi (ACTION_SCREEN_ON) iOS style lock screen kholta hai.
 * Chhota 1px overlay (SYSTEM_ALERT_WINDOW) Android ko batata hai ki hum background se activity khol sakte hain.
 */
class LockService : Service() {

    companion object {
        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, LockService::class.java))
            } catch (_: Throwable) {
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LockService::class.java))
        }
    }

    private var dot: View? = null

    private val screenOn = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_SCREEN_ON) showLock()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("lock_svc", "Lock screen service", NotificationManager.IMPORTANCE_MIN))
        nm.createNotificationChannel(NotificationChannel("lock_fs", "Lock screen", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null)
            enableVibration(false)
        })
        val n: Notification = NotificationCompat.Builder(this, "lock_svc")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Obsidian lock screen chalu hai")
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        registerReceiver(screenOn, IntentFilter(Intent.ACTION_SCREEN_ON))
        addDot()
    }

    private fun addDot() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = View(this)
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            dot = v
        } catch (_: Throwable) {
        }
    }

    private fun showLock() {
        val km = getSystemService(KeyguardManager::class.java)
        if (!km.isKeyguardLocked) return
        val i = Intent(this, LockActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try {
            startActivity(i)
        } catch (_: Throwable) {
        }
        // Backup: full screen intent (kuch phones par direct start block ho jata hai)
        try {
            val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(this, "lock_fs")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("Lock screen")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .setTimeoutAfter(3000)
                .build()
            getSystemService(NotificationManager::class.java).notify(2, n)
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenOn) } catch (_: Throwable) {}
        dot?.let {
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Throwable) {}
        }
        dot = null
        super.onDestroy()
    }
}
