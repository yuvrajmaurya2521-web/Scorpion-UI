package com.obsidian.launcher

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset

/** Saari settings yahin save hoti hain. Compose isse padhta hai to screen khud update hoti hai. */
class Store(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("obsidian", Context.MODE_PRIVATE)
    private var rev by mutableIntStateOf(0)

    private fun <T> r(f: () -> T): T {
        @Suppress("UNUSED_VARIABLE") val subscribe = rev
        return f()
    }

    private fun put(f: (SharedPreferences.Editor) -> Unit) {
        val e = sp.edit()
        f(e)
        e.apply()
        rev++
    }

    // ---- per-app glow ----
    fun color(pkg: String, def: Int): Int = r { sp.getInt("c_$pkg", def) }
    fun setColor(pkg: String, c: Int) = put { it.putInt("c_$pkg", c) }
    fun resetColor(pkg: String) = put { it.remove("c_$pkg") }

    fun speed(pkg: String): Float = r { sp.getFloat("s_$pkg", 1f) }
    fun setSpeed(pkg: String, v: Float) = put { it.putFloat("s_$pkg", v) }

    /** 0 = ghoomta glow, 1 = pulse, 2 = liquid */
    fun style(pkg: String): Int = r { sp.getInt("st_$pkg", 0) }
    fun setStyle(pkg: String, v: Int) = put { it.putInt("st_$pkg", v) }

    fun label(pkg: String, def: String): String = r { sp.getString("n_$pkg", null) ?: def }
    fun setLabel(pkg: String, v: String) = put { if (v.isBlank()) it.remove("n_$pkg") else it.putString("n_$pkg", v) }

    // ---- hidden apps ----
    val hidden: Set<String> get() = r { (sp.getStringSet("hidden", emptySet()) ?: emptySet()).toSet() }
    fun setHidden(pkg: String, h: Boolean) {
        val cur = hidden.toMutableSet()
        if (h) cur.add(pkg) else cur.remove(pkg)
        put { it.putStringSet("hidden", cur) }
    }

    // ---- home / dock layout (null = default) ----
    fun homeApps(): List<String>? = r { sp.getString("home", null)?.split("|")?.filter { it.isNotEmpty() } }
    fun setHome(list: List<String>) = put { it.putString("home", list.joinToString("|")) }
    fun dock(): List<String>? = r { sp.getString("dock", null)?.split("|")?.filter { it.isNotEmpty() } }
    fun setDock(list: List<String>) = put { it.putString("dock", list.joinToString("|")) }

    // ---- secret zone (screen ka fraction) ----
    fun zone(): Offset? = r { if (sp.contains("zx")) Offset(sp.getFloat("zx", 0f), sp.getFloat("zy", 0f)) else null }
    fun setZone(x: Float, y: Float) = put { it.putFloat("zx", x).putFloat("zy", y) }
    fun clearZone() = put { it.remove("zx").remove("zy") }

    // ---- generic settings ----
    fun str(k: String, d: String): String = r { sp.getString(k, d) ?: d }
    fun setStr(k: String, v: String) = put { it.putString(k, v) }
    fun bool(k: String, d: Boolean): Boolean = r { sp.getBoolean(k, d) }
    fun setBool(k: String, v: Boolean) = put { it.putBoolean(k, v) }
    fun int(k: String, d: Int): Int = r { sp.getInt(k, d) }
    fun setInt(k: String, v: Int) = put { it.putInt(k, v) }

    /** "bottom", "edge" ya "double" */
    val recentsGesture: String get() = str("g_recents", "double")
    /** "topright" ya "topfull" */
    val ccGesture: String get() = str("g_cc", "topright")
    val lockOn: Boolean get() = bool("lock_on", false)
    val lockFont: Int get() = int("lock_font", 2)
    val lockStack: Boolean get() = bool("lock_stack", true)
    val lockDepth: Boolean get() = bool("lock_depth", true)
    val lockImgRev: Int get() = int("lock_img_rev", 0)
}
