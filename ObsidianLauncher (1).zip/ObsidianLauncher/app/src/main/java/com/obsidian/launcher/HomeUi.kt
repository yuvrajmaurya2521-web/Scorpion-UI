package com.obsidian.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.ui.composed
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Touch ko consume kiye bina swipe dekhta hai (start point, total movement, size).
 * Isse pager aur icons ke gestures kharab nahi hote.
 */
fun Modifier.swipeWatcher(onEnd: (Offset, Offset, IntSize) -> Unit): Modifier = composed {
    val cb by rememberUpdatedState(onEnd)
    pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            var last = down.position
            while (true) {
                val ev = awaitPointerEvent(PointerEventPass.Initial)
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                last = ch.position
                if (!ch.pressed) break
            }
            cb(down.position, last - down.position, size)
        }
    }
}

private val TextShadow = TextStyle(shadow = Shadow(Color.Black, blurRadius = 8f))

@Composable
fun ClockWidget() {
    val now: State<Date> = produceState(Date()) {
        while (true) {
            value = Date()
            delay(15_000)
        }
    }
    val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now.value)
    val d = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now.value)
    Column(Modifier.padding(horizontal = 24.dp, vertical = 14.dp)) {
        Text(t, color = Color.White, fontSize = 52.sp, style = TextShadow)
        Text(d, color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp, style = TextShadow)
    }
}

@Composable
fun HomePager(
    apps: List<AppInfo>,
    store: Store,
    modifier: Modifier,
    onOpen: (AppInfo) -> Unit,
    onLong: (AppInfo) -> Unit
) {
    val pages = apps.chunked(20).ifEmpty { listOf(emptyList()) }
    val state = rememberPagerState { pages.size }
    Column(modifier) {
        HorizontalPager(state, Modifier.weight(1f)) { p ->
            Column(
                Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pages[p].chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { a ->
                            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                AppItem(a, store, true, { onOpen(a) }, { onLong(a) })
                            }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        if (pages.size > 1) {
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.Center) {
                repeat(pages.size) { i ->
                    Box(
                        Modifier
                            .padding(3.dp)
                            .size(6.dp)
                            .background(if (i == state.currentPage) Color.White else Color.White.copy(alpha = 0.3f), CircleShape)
                    )
                }
            }
        }
    }
}

@Composable
fun Dock(apps: List<AppInfo>, store: Store, onOpen: (AppInfo) -> Unit, onLong: (AppInfo) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .background(Color(0x33FFFFFF), RoundedCornerShape(30.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        apps.forEach { a -> AppItem(a, store, false, { onOpen(a) }, { onLong(a) }) }
    }
}

@Composable
fun Drawer(
    apps: List<AppInfo>,
    store: Store,
    onOpen: (AppInfo) -> Unit,
    onLong: (AppInfo) -> Unit,
    onClose: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    BackHandler(onBack = onClose)
    val list = if (q.isBlank()) apps else apps.filter { store.label(it.pkg, it.label).contains(q.trim(), ignoreCase = true) }
    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xEB08080D))
            .pointerInput(Unit) { detectTapGestures { } }
            .systemBarsPadding()
            .padding(horizontal = 12.dp)
    ) {
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 10.dp)
                .size(width = 44.dp, height = 5.dp)
                .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(3.dp))
                .clickable(onClick = onClose)
        )
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            placeholder = { Text("App dhundo") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { list.firstOrNull()?.let(onOpen) })
        )
        LazyVerticalGrid(
            GridCells.Fixed(4),
            Modifier.weight(1f),
            contentPadding = PaddingValues(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.pkg }) { a ->
                Box(contentAlignment = Alignment.Center) {
                    AppItem(a, store, true, { onOpen(a) }, { onLong(a) })
                }
            }
        }
    }
}

@Composable
fun VaultScreen(
    hiddenApps: List<AppInfo>,
    store: Store,
    onOpen: (AppInfo) -> Unit,
    onLong: (AppInfo) -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xF4050507))
            .pointerInput(Unit) { detectTapGestures { } }
            .systemBarsPadding()
            .padding(16.dp)
    ) {
        Text("Hidden vault", color = Color.White, fontSize = 24.sp)
        Text(
            "Ye apps drawer, search aur recents mein nahi dikhte. Icon dabake rakho to Unhide ka option milega.",
            color = Color(0xFF8D8D9C), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )
        if (hiddenApps.isEmpty()) {
            Text("Abhi koi app hidden nahi hai.", color = Color.White.copy(alpha = 0.7f), modifier = Modifier.weight(1f))
        } else {
            LazyVerticalGrid(
                GridCells.Fixed(4),
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(hiddenApps, key = { it.pkg }) { a ->
                    Box(contentAlignment = Alignment.Center) {
                        AppItem(a, store, true, { onOpen(a) }, { onLong(a) })
                    }
                }
            }
        }
        Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Vault lock karo") }
    }
}
