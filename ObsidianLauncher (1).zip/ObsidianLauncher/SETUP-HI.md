# ObsidianLauncher: phone par setup (Hindi)

## 1. GitHub par files daalo (sirf phone se)
1. Zip ko phone mein extract karo (Files app, "Extract").
2. GitHub app/web mein apni repo kholo. Purani sab files delete karo (ObsidianLauncher folder, build.gradle.kts, settings.gradle.kts, app/ sab).
3. Extract kiye hue folder ki SAARI files upload karo (Add file > Upload files). Dhyan rakho:
   - `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `app/` repo ke ROOT mein hon.
   - `.github/workflows/build.yml` bhi upload ho. Agar hidden folder upload nahi ho raha, GitHub web mein "Create new file" karke naam `.github/workflows/build.yml` likho aur uska content paste karo.
4. Commit karo (main branch).

## 2. APK banao
1. Repo mein Actions tab kholo. "Build APK" chalna shuru ho jayega (5 se 10 minute).
2. Green tick aane par us run ko kholo. Neeche Artifacts mein `ObsidianLauncher-debug-apk` download karo, zip extract karo, `app-debug.apk` install karo.
3. Build fail ho to run ke "Build debug APK" step ka laal error text copy karke mujhe bhejo. Main seedha fix kar dunga.

## 3. Install ke baad permissions (Vivo T2x, Funtouch OS 15)
- Home dabao, "Obsidian" ko default launcher chuno (ya Settings > Apps > Default apps > Home app).
- Settings > Apps > Obsidian ke 3-dot menu mein "Allow restricted settings" dabao. Ye step Accessibility ke liye zaroori hai, nahi to option grey rahega.
- Wallpaper dabake rakho > "Settings aur permissions". Wahan se ek ek karke:
  1. Usage Access: Obsidian ON (Recents ke liye)
  2. Display over other apps: ON (lock screen ke liye)
  3. Accessibility: "Obsidian Control Center" ON (Control Center ke liye)
  4. Modify system settings: ON (brightness, rotate)
  5. Notifications: Allow
  6. Full screen intents: ON (agar option dikhe)
- Battery: Settings > Battery > Background power consumption > Obsidian ko "Allow high power consumption" karo, aur i Manager mein Autostart ON karo. Isse lock screen service band nahi hogi.

## 4. Kaise use karna hai
- Icon dabake rakho: glow ka color, hue slider, style, speed, naam, Hide, App info, Uninstall, Home/Dock.
- Khali wallpaper dabake rakho: menu (Wallpaper badlo, Apps hide, Secret zone, Settings).
- Secret zone: menu se "Secret zone set karo", phir wallpaper par jahan chaho tap karo. Baad mein wahin tap karoge to fingerprint/face/PIN maangega aur Vault khulega. Koi nishaan nahi dikhta.
- Recents: default double-tap. Settings mein badal sakte ho (neeche se swipe ya side edge).
- Control Center: screen ke upar-right kone se neeche swipe.
- Lock screen: Settings mein "Lock screen chalu karo". Depth effect ke liye kisi bhi gallery app se subject ka transparent PNG (background removed) banao aur "Depth cutout PNG chuno" se daalo.

## 5. Android ki seemayein (seedhi baat)
- System ka Recents button/gesture kisi launcher se replace nahi hota. Hamara switcher launcher ke andar gesture se khulta hai.
- Hidden apps hamare drawer, search aur recents se gayab hain. Par agar tum vault se koi hidden app kholo to phone ka apna system Recents use dikha sakta hai.
- Wi-Fi, Bluetooth aur Mobile data ko Android 10+ par normal app seedha on/off nahi kar sakta, isliye tile system panel kholti hai. Torch, brightness, volume, rotate seedhe chalte hain.
- Lock screen asli lock ko replace nahi karti. Screen on hone par ye upar dikhti hai, upar swipe par asli PIN/fingerprint aata hai.
- Recents card se app asli mein band nahi hoti (iske liye Shizuku chahiye). Card sirf list se hatta hai.
